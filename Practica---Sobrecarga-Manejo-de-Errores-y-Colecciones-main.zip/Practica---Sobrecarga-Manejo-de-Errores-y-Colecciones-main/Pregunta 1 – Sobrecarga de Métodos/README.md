Esta solución crea una clase con tres métodos, cada uno con parámetros diferentes, y un método para demostrar su uso. 
