Este programa le pide al usuario dos números enteros y realiza una división, usando un bloque para manejar un potencial si el segundo número es cero.
