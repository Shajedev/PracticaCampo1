Este programa utiliza un bloque para manejar dos tipos diferentes de excepciones: para la entrada no numérica y una personalizada para números negativos.
