Este código muestra el uso de un para almacenar, mostrar, quitar y, a continuación, volver a mostrar una lista de nombres de alumnos. 
