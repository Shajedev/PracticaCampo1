Esta solución combina la sobrecarga de métodos, el almacenamiento y el manejo de errores para administrar un inventario simple. Garantiza que los precios y las cantidades no sean negativos. 
